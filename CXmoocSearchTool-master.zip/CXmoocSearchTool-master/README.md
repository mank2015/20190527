![GitHub](https://img.shields.io/github/license/yanyongyu/CXmoocSearchTool.svg)
![GitHub All Releases](https://img.shields.io/github/downloads/yanyongyu/CXmoocSearchTool/total.svg)
![GitHub repo size in bytes](https://img.shields.io/github/repo-size/yanyongyu/CXmoocSearchTool.svg)

## 浏览器插件全自动挂机请参考：
https://github.com/CodFrm/cxmooc-tools

本搜题exe作为插件补充

可在插件题库未能找到答案或考试时使用

## exe功能
多来源题库查询

批量查询

窗口置顶

## QQ群
[614202391](https://shang.qq.com/wpa/qunwpa?idkey=9bddd2564d84bd999940de422d1c0c70f87ecaf02fe9d7c60389fc2b376179eb)

## api.py
有python环境的可以只下载api.py
![GitHub file size in bytes](https://img.shields.io/github/size/yanyongyu/CXmoocSearchTool/api.py.svg)

在终端/cmd中运行

```MS-DOS
python api.py -h
```

获取帮助
